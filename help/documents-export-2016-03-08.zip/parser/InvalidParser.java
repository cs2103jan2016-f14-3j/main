package parser;

public class InvalidParser {
	public InvalidParser(String userCommand){
	}

}
