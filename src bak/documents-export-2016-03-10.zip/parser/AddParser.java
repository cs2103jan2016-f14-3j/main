package parser;

import java.util.Date;
import java.util.List;

import command.Command;
import command.InvalidCommand;
import command.AddCommand;
import org.ocpsoft.prettytime.nlp.PrettyTimeParser;
import org.ocpsoft.prettytime.nlp.parse.DateGroup;


public class AddParser extends ArgsParser{
	
	/*
	 * Possible add commands:
	 * add title = adds title without any extra stuff
	 * add title date = add title + date
	 * add title:desc date = add title + desc + date
	 * add title:desc p:high date = add title + description + priority + date
	 * add title:desc p:high l:label date = add title + desc + priority + label + date
	 * add title:desc p:high l:label s:startdate date = add title desc priority + label + startdate + enddate 
	 */
	
	private String itemTitle= null;
	private String itemDescription = null;
	private String itemPriority = null;
	private String itemStatus = null;
	private String itemLabel = null;
	private Date itemStartDate = null;
	private Date itemEndDate = null;
	
	private List<DateGroup> dateGroups;
	private List<Date> dateList;

	private String argsWithoutDates;
	
	public AddParser(String userCommand){
		super(userCommand);
		argsWithoutDates = this.commandArgumentsString;
		PrettyTimeParser timeParser = new PrettyTimeParser();
		if (this.noArgs){
			invalidArgs();
			return;
		} else {		
			dateGroups = timeParser.parseSyntax(this.commandArgumentsString);
			if (dateGroups.size()>0){
				int index = commandArgumentsString.indexOf(dateGroups.get(0).getText());
				argsWithoutDates=commandArgumentsString.substring(0,index);
				
				dateList = dateGroups.get(0).getDates();
				
				System.out.println(dateList);
				//System.out.println();
				//Get dates
				itemEndDate = getEndDate();
				itemStartDate = getStartDate();
			}

			//Get text
			
			extractPriority();
			extractStatus();
			extractLabel();
			extractDescription();
			itemTitle = argsWithoutDates.trim();
		}
	}
	
	public Command executeCommand(){
		if (itemTitle==""){
			return new InvalidCommand(commandArgumentsString);
		}
		if (itemDescription==null && itemPriority==null && itemStatus==null && itemLabel==null && itemStartDate==null && itemEndDate==null){
			return new AddCommand(itemTitle);
		} else if (itemDescription==null && itemPriority==null && itemStatus==null && itemLabel==null && itemStartDate==null){
			return new AddCommand(itemTitle, itemEndDate);
		} else{
			System.out.println("title:" + itemTitle + " desc:" + itemDescription + " prio:" + itemPriority + " status:" + itemStatus + " label:" + itemLabel + " start:" + itemStartDate + " end:" + itemEndDate);
			return new AddCommand(itemTitle, itemDescription, itemPriority, itemStatus, itemLabel, itemStartDate, itemEndDate);
		}
	}
	
	private void extractDescription(){
		int index = argsWithoutDates.indexOf(":");
		int indexSpace = argsWithoutDates.indexOf(" ",index);
		if (index>0){
			itemDescription = argsWithoutDates.substring(index+1, indexSpace);
			argsWithoutDates = argsWithoutDates.substring(0, index)+argsWithoutDates.substring(indexSpace);
		}
	}
	
	public void extractPriority(){
		int index = argsWithoutDates.indexOf("p:");
		int indexSpace = argsWithoutDates.indexOf(" ",index);
		if (index>0){
			itemPriority = argsWithoutDates.substring(index+2, indexSpace);
			argsWithoutDates = argsWithoutDates.substring(0, index)+argsWithoutDates.substring(indexSpace);
		}

	}
	
	public void extractStatus(){
		int index = argsWithoutDates.indexOf("s:");
		int indexSpace = argsWithoutDates.indexOf(" ",index);
		if (index>0){
			itemStatus = argsWithoutDates.substring(index+2, indexSpace);
			argsWithoutDates = argsWithoutDates.substring(0, index)+argsWithoutDates.substring(indexSpace);
		}
	}
	
	public void extractLabel(){
		int index = argsWithoutDates.indexOf("l:");
		int indexSpace = argsWithoutDates.indexOf(" ",index);
		if (index>0){
			itemLabel = argsWithoutDates.substring(index+2, indexSpace);
			argsWithoutDates = argsWithoutDates.substring(0, index)+argsWithoutDates.substring(indexSpace);
		}
	}
	
	public Date getStartDate(){ 
		if (dateList.size()>1){
			return dateList.get(0);
		} else{
			return null;
		}
	}
	
	public Date getEndDate(){ 
		if (dateList.size()>1){
			return dateList.get(1);
		} else{
			return dateList.get(0);
		}
	}
	
}
