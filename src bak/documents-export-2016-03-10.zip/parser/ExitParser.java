package parser;

//import command.Command;
//import command.ExitCommand;

public class ExitParser {
	public void executeCommand(){
		return ExitCommand();
	}
}
